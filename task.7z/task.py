#!/usr/bin/python

import sys, getopt
import hashlib
import random
import string
import click
import itertools

def random_string(size):
    return ''.join(random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') for _ in range(size))

def md5(string):
    return hashlib.md5(string.encode('utf-8')).hexdigest()

def main(argv):
    m = '0x00'
    n = '10'
    f = 'randomfile.txt'
    h = 'md5_undefined'
    s = 'string_undefined'
    try:
        opts, args = getopt.getopt(argv,'m:n:f')
    except getopt.GetoptError:
        print 'USAGE: hash.py -m <md5 first byte> -n <number of chars in result string> -f <output file>'
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-m':
            try:
                m = int(arg,16)
            except ValueError:
                print 'enter a valid HEX-digit'
                sys.exit(2)
            if 0 <= m <= 255:
                    m = hex(m)
            else:
                print 'enter a valid HEX-digit'
                sys.exit(2)
        if opt == '-n':
            try: 
                n = int(arg)
            except ValueError:
                print 'enter a valid integer'
                sys.exit(2)
            if n < 0:
                print 'enter a valid integer'
                sys.exit(2)
            if n == 0:
                print 'You entered 0 for string length. MD5 from empty string is constant: d41d8cd98f00b204e9800998ecf8427e'
                sys.exit(2)
            if n >= 10000000:
                if click.confirm('The length is to big, I will probably hang. Are you sure?', default=False):
                    n = int(arg)
                else:
                    sys.exit(2)
        if opt == '-f':
            if (arg != ''):
                f = arg
            else:
                print 'filename is invalid, output will be saved to {}'.format(f)
    orig_stdout = sys.stdout
    output = open(f,'w')
    sys.stdout = output
    if n <= 3:
        strings = itertools.combinations('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',n)
        i = 0
        for string in strings:
            s = ''.join(string)
            h = md5(s)
            fb = hex(int(h[:2],16))
            i = i + 1
            if fb == m:
                print 'Got in {} : {} {}'.format(i,h,s)
                break
        else:
            print 'Not found'
    else:
        s = random_string(n)
        h = md5(s)
        fb = hex(int(h[:2],16))
        i = 0;
        while fb != m:
            s = random_string(n)
            h = md5(s)
            fb = hex(int(h[:2],16))
            i = i + 1
        print 'Got in {} : {} {}'.format(i,h,s)
    sys.stdout = orig_stdout
    output.close()
if __name__ == "__main__":
    main(sys.argv[1:])